
package quicke;

/**
 *
 * @author brawd
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class QuickE {

    public static void main(String[] args) {
        String usuario = "root";
        String password = "";
        
        String url = "jdbc:mysql://localhost:3306/quickez";
        //citar la base de datos MYSQL
        
        Connection conexion;
        Statement statement;
        ResultSet rs;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(QuickE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try{
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();
            
            //insertar datos con comandos MYSQL
            //statement.executeUpdate("INSERT INTO CLIENTES(NUM_DOCUMENTO, NOMBRE, EMAIL) VALUES('123076423', 'Sandra Camargo', 'sandr4s@gmail.com')");
            
            //actualziar datos con comandos MYSQL
            //statement.executeUpdate("UPDATE CLIENTES SET NUM_DOCUMENTO = '36303749' WHERE NOMBRE = 'Sandra Camargo'");

            //eliminar un dato de la tabla con conmados MYSQL
            //statement.executeUpdate("DELETE FROM CLIENTES WHERE NOMBRE = 'Sandra Camargo'");

            rs = statement.executeQuery("SELECT * FROM CLIENTES");
            //traer la tabla clientes de la base de datos quickez
            
            rs.next();
            do{
                System.out.println(rs.getInt("num_documento")+" : "+rs.getString("nombre")+ " : "+rs.getString("email"));
                //imprimir en la consola de NetBeans, las variables 'nombre' y 'email' de la tabla clientes
                
            }while(rs.next());
            
        } catch (SQLException ex){
            Logger.getLogger(QuickE.class.getName()).log(Level.SEVERE, null, ex);

        }
        
    }
}
   
